# PLEXOS from Mac — terminal setup files

Follow the companion note: https://alejandrogne.github.io/notes/plexos-cloud-mac-terminal-setup/

Before starting, install Docker Desktop, obtain the official Linux x64 CLI ZIP from PLEXOS Cloud Marketplace, and prepare the credentials file described at https://alejandrogne.github.io/notes/plexos-cloud-service-principal-setup/ .

Extract the entire CLI package into `cli/`, then run `chmod +x cli/plexos-cloud`.

From Mac Terminal, in this folder:

```bash
./plexos build
./plexos shell
```

Inside Linux:

```bash
pxc --version
pxc environment get
# Set the environment if needed, before login (NA, EMEA, APAC, etc.).
pxc-login
pxc-check
exit
```

Reopen with `./plexos shell`. Working files under `/workspace` are stored in this folder's `workspace/` directory on the Mac. Login state persists in the Docker volume `plexos-mac-terminal-state`. Run one session at a time. Deleting that volume removes the saved session.

The launcher defaults to `~/.config/plexos-cloud/service-principal.env`. An existing file can be selected without copying it: `PXC_ENV_FILE="/absolute/path/to/credentials.env" ./plexos shell`.

The helper names `pxc-login` and `pxc-check` are provided by this starter; they are not vendor CLI commands.

This setup was verified with Marketplace Linux Toolkit 1.5.2981.559 (CLI version 1.5.2981), bundling .NET 10.0.8. No separate .NET runtime is installed in the image. The package is mounted read-only; CLI upgrades should be downloaded on the Mac rather than installed in place inside the container.

The starter contains no vendor CLI binaries or credentials. Python in the image is Ubuntu 22.04's distribution version; this starter does not set up the Python SDKs.
